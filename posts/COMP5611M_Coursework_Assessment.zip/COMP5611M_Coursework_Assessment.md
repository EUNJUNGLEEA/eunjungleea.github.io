# **Predict Cancer Mortality Rates in US Counties**

The provided dataset comprises data collected from multiple counties in the US. The regression task for this assessment is to predict cancer mortality rates in "unseen" US counties, given some training data. The training data ('Training_data.csv') comprises various features/predictors related to socio-economic characteristics, amongst other types of information for specific counties in the country. The corresponding target variables for the training set are provided in a separate CSV file ('Training_data_targets.csv'). Use the notebooks provided for lab sessions throughout this module to provide solutions to the exercises listed below. Throughout all exercises text describing your code and answering any questions included in the exercise descriptions should be included as part of your submitted solution.

Note - We also provide an example test data set ('Test_data_example.csv' and 'Test_data_example_targets.csv'). This is just an example of the final test set (which will NOT be provided to you) that will be used to evaluate your solutions when your submitted solutions are being marked. The provided Test data (I.e. 'Test_data_example.csv' and 'Test_data_example_targets.csv') is NOT to be used as an independent test set when developing your models, but only to prepare your 'prediction/inference' script to make predictions on completely unseen data. Part of this assessment requires you to write such an inference script that evaluates your best, trained regression model on the final test data set such that, we are able to run the inference script ourselves on the unseen (i.e. data we have not provided to you) test data. Yyou can use the example test data ('Test_data_example.csv' and 'Test_data_example_targets.csv') to verify that it works prior to submission.

The list of predictors/features available in this data set are described below:

**Data Dictionary**

avgAnnCount: Mean number of reported cases of cancer diagnosed annually

avgDeathsPerYear: Mean number of reported mortalities due to cancer

incidenceRate: Mean per capita (100,000) cancer diagoses

medianIncome: Median income per county 

popEst2015: Population of county 

povertyPercent: Percent of populace in poverty 

MedianAge: Median age of county residents 

MedianAgeMale: Median age of male county residents 

MedianAgeFemale: Median age of female county residents 

AvgHouseholdSize: Mean household size of county 

PercentMarried: Percent of county residents who are married 

PctNoHS18_24: Percent of county residents ages 18-24 highest education attained: less than high school 

PctHS18_24: Percent of county residents ages 18-24 highest education attained: high school diploma 

PctSomeCol18_24: Percent of county residents ages 18-24 highest education attained: some college 

PctBachDeg18_24: Percent of county residents ages 18-24 highest education attained: bachelor's degree 

PctHS25_Over: Percent of county residents ages 25 and over highest education attained: high school diploma 

PctBachDeg25_Over: Percent of county residents ages 25 and over highest education attained: bachelor's degree 

PctEmployed16_Over: Percent of county residents ages 16 and over employed 

PctUnemployed16_Over: Percent of county residents ages 16 and over unemployed 

PctPrivateCoverage: Percent of county residents with private health coverage 

PctPrivateCoverageAlone: Percent of county residents with private health coverage alone (no public assistance) 

PctEmpPrivCoverage: Percent of county residents with employee-provided private health coverage 

PctPublicCoverage: Percent of county residents with government-provided health coverage 

PctPubliceCoverageAlone: Percent of county residents with government-provided health coverage alone 

PctWhite: Percent of county residents who identify as White 

PctBlack: Percent of county residents who identify as Black 

PctAsian: Percent of county residents who identify as Asian 

PctOtherRace: Percent of county residents who identify in a category which is not White, Black, or Asian 

PctMarriedHouseholds: Percent of married households 

BirthRate: Number of live births relative to number of women in county 


```python
import os
import pandas as pd

root_dir = './' # this is to be defined by you 
local_path = 'Data-for-students-regression/' # store the related data files in this folder

data_dir = root_dir + local_path
print(data_dir)

## Define paths to the training data and targets files
training_data_path = data_dir + 'Training_data.csv'
training_targets_path = data_dir + 'Training_data_targets.csv'
```

    ./Data-for-students-regression/
    


```python
import warnings
warnings.filterwarnings('ignore')
```

# **Exercise 1**

Read in the training data and targets files. The training data comprises features/predictors while the targets file comprises the targets (i.e. cancer mortality rates in US counties) you need to train models to predict. Plot histograms of all features to visualise their distributions and identify outliers. Do you notice any unusual values for any of the features? If so comment on these in the text accompanying your code. Compute correlations of all features with the target variable (across the data set) and sort them according the strength of correlations. Which are the top five features with strongest correlations to the targets? Plot these correlations using the scatter matrix plotting function available in pandas and comment on at least two sets of features that show visible correlations to each other. (5 marks)

# **Sample Answer to Exercise 1**

### 1) Plot histograms

Based on the histograms of the input features, two observations can be made: Firstly, there appears to be a feature with outliers in its distribution, and secondly, another feature displays values that seem to be unusual.


```python
import pandas as pd

# read the training and targets files
train = pd.read_csv(training_data_path)
target = pd.read_csv(training_targets_path)
```


```python
# Plot histograms of all input features
%matplotlib inline
import matplotlib.pyplot as plt

train.hist(bins=50,figsize=(20,15))
```




    array([[<AxesSubplot:title={'center':'avgAnnCount'}>,
            <AxesSubplot:title={'center':'avgDeathsPerYear'}>,
            <AxesSubplot:title={'center':'incidenceRate'}>,
            <AxesSubplot:title={'center':'medIncome'}>,
            <AxesSubplot:title={'center':'popEst2015'}>,
            <AxesSubplot:title={'center':'povertyPercent'}>],
           [<AxesSubplot:title={'center':'studyPerCap'}>,
            <AxesSubplot:title={'center':'MedianAge'}>,
            <AxesSubplot:title={'center':'MedianAgeMale'}>,
            <AxesSubplot:title={'center':'MedianAgeFemale'}>,
            <AxesSubplot:title={'center':'AvgHouseholdSize'}>,
            <AxesSubplot:title={'center':'PercentMarried'}>],
           [<AxesSubplot:title={'center':'PctNoHS18_24'}>,
            <AxesSubplot:title={'center':'PctHS18_24'}>,
            <AxesSubplot:title={'center':'PctSomeCol18_24'}>,
            <AxesSubplot:title={'center':'PctBachDeg18_24'}>,
            <AxesSubplot:title={'center':'PctHS25_Over'}>,
            <AxesSubplot:title={'center':'PctBachDeg25_Over'}>],
           [<AxesSubplot:title={'center':'PctEmployed16_Over'}>,
            <AxesSubplot:title={'center':'PctUnemployed16_Over'}>,
            <AxesSubplot:title={'center':'PctPrivateCoverage'}>,
            <AxesSubplot:title={'center':'PctPrivateCoverageAlone'}>,
            <AxesSubplot:title={'center':'PctEmpPrivCoverage'}>,
            <AxesSubplot:title={'center':'PctPublicCoverage'}>],
           [<AxesSubplot:title={'center':'PctPublicCoverageAlone'}>,
            <AxesSubplot:title={'center':'PctWhite'}>,
            <AxesSubplot:title={'center':'PctBlack'}>,
            <AxesSubplot:title={'center':'PctAsian'}>,
            <AxesSubplot:title={'center':'PctOtherRace'}>,
            <AxesSubplot:title={'center':'PctMarriedHouseholds'}>],
           [<AxesSubplot:title={'center':'BirthRate'}>, <AxesSubplot:>,
            <AxesSubplot:>, <AxesSubplot:>, <AxesSubplot:>, <AxesSubplot:>]],
          dtype=object)




    
![png](output_7_1.png)
    



```python
# Plot histograms of target: normally distributed
target.hist(bins=50)
```




    array([[<AxesSubplot:title={'center':'TARGET_deathRate'}>]], dtype=object)




    
![png](output_8_1.png)
    


### 2) Outlier Report

**[Outliers]**
- The feature 'AvgHouseholdSize' appears to have unusual values, and its distribution resembles that of a distribution with outliers.

- Generally, in distribution with outliers, there is a low bar located far from the other bars, which represents the outliers.
 
- The scatter plot in the following chunk shows a vertical line at zero. It needs to be removed because they are artefacts and model needs to learn smooth distribution.


```python
# To check the details, histogram and scatter plot
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize=(20,8))

train['AvgHouseholdSize'].hist(ax = axes[0])
axes[0].set_title("Histogram of AvgHouseholdSize", fontsize = 20)

plt.scatter(train['AvgHouseholdSize'], target['TARGET_deathRate'])
axes[1].set_title("Relationship between Target value", fontsize = 20)
```




    Text(0.5, 1.0, 'Relationship between Target value')




    
![png](output_10_1.png)
    



```python
# outliers are less than 0.5 from the scatter plot
outlier = train['AvgHouseholdSize']< 0.5
outlier_index = train[outlier].index

# remove from original datset
train.drop(outlier_index, inplace = True)
target.drop(outlier_index, inplace = True)
```


```python
# plot after removing outliers, and it seems more reasonable 
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize=(20,8))

train['AvgHouseholdSize'].hist(ax = axes[0])
axes[0].set_title("Histogram of AvgHouseholdSize", fontsize = 20)

plt.scatter(train['AvgHouseholdSize'], target)
axes[1].set_title("Relationship between Target value", fontsize = 20)
```




    Text(0.5, 1.0, 'Relationship between Target value')




    
![png](output_12_1.png)
    


**[Unusal Value Report]**
- According to the data dictionary, 'MedianAge' indicates the median age of county residents. Therefore, it is unlikely for its value to be between 400 and 600 because the value means age.
- However, the histogram and scatter plot show values between 400 and 600 for 'MedianAge', which seems to be unusual with the data dictionary's definition.
- These values need to be removed.


```python
# To check the details, histogram and scatter plot
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize=(20,8))

train['MedianAge'].hist(ax = axes[0], bins=50)
axes[0].set_title("Histogram of MedianAge", fontsize = 20)

plt.scatter(train['MedianAge'], target['TARGET_deathRate'])
axes[1].set_title("Relationship between Target value", fontsize = 20)
```




    Text(0.5, 1.0, 'Relationship between Target value')




    
![png](output_14_1.png)
    



```python
# outliers are less than 0.5 from the scatter plot
unusal = train['MedianAge'] > 100
unusal_index = train[unusal].index

# remove from original datset
train.drop(unusal_index, inplace = True)
target.drop(unusal_index, inplace = True)
```


```python
# plot after removing unusual value, and it seems more reasonable 
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize=(20,8))

train['MedianAge'].hist(ax = axes[0])
axes[0].set_title("Histogram of MedianAge", fontsize = 20)

plt.scatter(train['MedianAge'], target)
axes[1].set_title("Relationship between Target value", fontsize = 20)
```




    Text(0.5, 1.0, 'Relationship between Target value')




    
![png](output_16_1.png)
    


### 3) Correlation of all features with the target variable


```python
# Compute correlations of all features with the target variable 
train_attributes = train.columns

feature = []
correlation = []

# calculate the correlation using for loop
for i in range(len(train_attributes)):
    corr = train[train_attributes[i]].corr(target['TARGET_deathRate'])
    correlation.append(corr)
    feature.append(train_attributes[i])

# create dataframe to check feature name and correlation coefficient 
df_corr = pd.DataFrame(zip(feature, correlation), columns = ['feature', 'corr'])

# sort them according the strength of correlations
df_corr = df_corr.iloc[(-df_corr['corr'].abs()).argsort()].reset_index(drop=True)
df_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature</th>
      <th>corr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>PctBachDeg25_Over</td>
      <td>-0.491019</td>
    </tr>
    <tr>
      <th>1</th>
      <td>PctPublicCoverageAlone</td>
      <td>0.440050</td>
    </tr>
    <tr>
      <th>2</th>
      <td>incidenceRate</td>
      <td>0.438377</td>
    </tr>
    <tr>
      <th>3</th>
      <td>medIncome</td>
      <td>-0.419169</td>
    </tr>
    <tr>
      <th>4</th>
      <td>povertyPercent</td>
      <td>0.418191</td>
    </tr>
    <tr>
      <th>5</th>
      <td>PctHS25_Over</td>
      <td>0.411210</td>
    </tr>
    <tr>
      <th>6</th>
      <td>PctEmployed16_Over</td>
      <td>-0.404002</td>
    </tr>
    <tr>
      <th>7</th>
      <td>PctPublicCoverage</td>
      <td>0.391543</td>
    </tr>
    <tr>
      <th>8</th>
      <td>PctPrivateCoverage</td>
      <td>-0.387854</td>
    </tr>
    <tr>
      <th>9</th>
      <td>PctUnemployed16_Over</td>
      <td>0.365140</td>
    </tr>
    <tr>
      <th>10</th>
      <td>PctPrivateCoverageAlone</td>
      <td>-0.360537</td>
    </tr>
    <tr>
      <th>11</th>
      <td>PctMarriedHouseholds</td>
      <td>-0.294054</td>
    </tr>
    <tr>
      <th>12</th>
      <td>PctBachDeg18_24</td>
      <td>-0.286767</td>
    </tr>
    <tr>
      <th>13</th>
      <td>PercentMarried</td>
      <td>-0.270286</td>
    </tr>
    <tr>
      <th>14</th>
      <td>PctHS18_24</td>
      <td>0.268260</td>
    </tr>
    <tr>
      <th>15</th>
      <td>PctEmpPrivCoverage</td>
      <td>-0.258555</td>
    </tr>
    <tr>
      <th>16</th>
      <td>PctBlack</td>
      <td>0.241638</td>
    </tr>
    <tr>
      <th>17</th>
      <td>PctSomeCol18_24</td>
      <td>-0.194756</td>
    </tr>
    <tr>
      <th>18</th>
      <td>PctOtherRace</td>
      <td>-0.182543</td>
    </tr>
    <tr>
      <th>19</th>
      <td>PctAsian</td>
      <td>-0.182094</td>
    </tr>
    <tr>
      <th>20</th>
      <td>PctWhite</td>
      <td>-0.177209</td>
    </tr>
    <tr>
      <th>21</th>
      <td>avgAnnCount</td>
      <td>-0.152698</td>
    </tr>
    <tr>
      <th>22</th>
      <td>popEst2015</td>
      <td>-0.130355</td>
    </tr>
    <tr>
      <th>23</th>
      <td>PctNoHS18_24</td>
      <td>0.097600</td>
    </tr>
    <tr>
      <th>24</th>
      <td>avgDeathsPerYear</td>
      <td>-0.095143</td>
    </tr>
    <tr>
      <th>25</th>
      <td>BirthRate</td>
      <td>-0.093588</td>
    </tr>
    <tr>
      <th>26</th>
      <td>MedianAgeMale</td>
      <td>-0.030434</td>
    </tr>
    <tr>
      <th>27</th>
      <td>AvgHouseholdSize</td>
      <td>-0.029599</td>
    </tr>
    <tr>
      <th>28</th>
      <td>studyPerCap</td>
      <td>-0.024806</td>
    </tr>
    <tr>
      <th>29</th>
      <td>MedianAge</td>
      <td>-0.012477</td>
    </tr>
    <tr>
      <th>30</th>
      <td>MedianAgeFemale</td>
      <td>0.007456</td>
    </tr>
  </tbody>
</table>
</div>




```python
# display the top five features with strongest correlations to the targets
df_corr.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature</th>
      <th>corr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>PctBachDeg25_Over</td>
      <td>-0.491019</td>
    </tr>
    <tr>
      <th>1</th>
      <td>PctPublicCoverageAlone</td>
      <td>0.440050</td>
    </tr>
    <tr>
      <th>2</th>
      <td>incidenceRate</td>
      <td>0.438377</td>
    </tr>
    <tr>
      <th>3</th>
      <td>medIncome</td>
      <td>-0.419169</td>
    </tr>
    <tr>
      <th>4</th>
      <td>povertyPercent</td>
      <td>0.418191</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot these correlation(top 5) using scatter matrix from pandas
from pandas.plotting import scatter_matrix

# name of the top five strongest correlations features 
attributes=["PctBachDeg25_Over","incidenceRate","PctPublicCoverageAlone","medIncome", "povertyPercent"]

# merge the dataframe to generate scatter plot
merge = pd.concat([train[attributes], target], axis=1)

# plot the result
scatter_matrix(merge,figsize=(20,15))
```




    array([[<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='PctBachDeg25_Over'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='PctBachDeg25_Over'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='PctBachDeg25_Over'>,
            <AxesSubplot:xlabel='medIncome', ylabel='PctBachDeg25_Over'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='PctBachDeg25_Over'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='PctBachDeg25_Over'>],
           [<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='incidenceRate'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='incidenceRate'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='incidenceRate'>,
            <AxesSubplot:xlabel='medIncome', ylabel='incidenceRate'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='incidenceRate'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='incidenceRate'>],
           [<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='PctPublicCoverageAlone'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='PctPublicCoverageAlone'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='PctPublicCoverageAlone'>,
            <AxesSubplot:xlabel='medIncome', ylabel='PctPublicCoverageAlone'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='PctPublicCoverageAlone'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='PctPublicCoverageAlone'>],
           [<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='medIncome'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='medIncome'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='medIncome'>,
            <AxesSubplot:xlabel='medIncome', ylabel='medIncome'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='medIncome'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='medIncome'>],
           [<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='povertyPercent'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='povertyPercent'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='povertyPercent'>,
            <AxesSubplot:xlabel='medIncome', ylabel='povertyPercent'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='povertyPercent'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='povertyPercent'>],
           [<AxesSubplot:xlabel='PctBachDeg25_Over', ylabel='TARGET_deathRate'>,
            <AxesSubplot:xlabel='incidenceRate', ylabel='TARGET_deathRate'>,
            <AxesSubplot:xlabel='PctPublicCoverageAlone', ylabel='TARGET_deathRate'>,
            <AxesSubplot:xlabel='medIncome', ylabel='TARGET_deathRate'>,
            <AxesSubplot:xlabel='povertyPercent', ylabel='TARGET_deathRate'>,
            <AxesSubplot:xlabel='TARGET_deathRate', ylabel='TARGET_deathRate'>]],
          dtype=object)




    
![png](output_20_1.png)
    


### Comment on at least two sets of features that show visible correlations to each other

**Strongest correlations to the targets**
- PctPublicCoverageAlone / Target_deathRate:
There is a positive correlation between "PctPublicCoverageAlone" and the target value. From this, we can see that the higher percentage of residents with government-provided health coverage alone, the higher the cancer mortality rate.

- povertyPercent / Target_deathRate:
There is a positive correlation between "povertyPercent" and the target value. From this, we can see that the higher percentage of the populace in poverty, the higher the cancer mortality rate.


**Correlation between input features**<br>
From the scatter matrix, we can also see that there is not only a correlation between features and target but a correlation between input features. Generally, highly correlated features are not affecting making predictions but they could affect making interpretations of the model.

- PctPublicCoverageAlone / povertyPercent:
There is a positive correlation between "PctPublicCoverageAlone" and "povertyPercent". It means the higher percentage of rate of poverty, the higher percentage of residents with government-provided health coverage alone.

- medIncome / povertyPercent:
There is a negative correlation between "medIncome" and "povertyPercent". It means the higher percentage of rate of poverty, the lower the median income.

# **Exercise 2**

Create an ML pipeline using scikit-learn (as demonstrated in the lab notebooks) to pre-process the training data. (3 marks)

# **Sample Answer to Exercise 2**

### 1) Split the dataset

Before constructing the ML pipeline, it is necessary to split the dataset into a training set and a test set. The training set will be utilized for model training purposes, while the test set will be utilized for model evaluation. To ensure a fair and reasonable evaluation of the model's performance, the test set must be independent and unseen by the model during the training process.


```python
# split the data into trainset and testset before imputation
from sklearn.model_selection import train_test_split

# split data of input features 
train_rg, test_rg = train_test_split(train, test_size= 0.2, random_state=42)

# split data of target features 
target_rg, target_test_rg = train_test_split(target, test_size= 0.2, random_state=42)
```

### 2) Pipeline plan

**- Missing value**<br>
Missing values will be replaced by the median. The one thing that is concerned about replacing missing values is that 'PctSomeCol18_24' has only 585 values out of 2364 values (most of them are missing) and "PctPrivateCoverageAlone" has 1895 values out of 2364 values (19.8% is missing).

**- Scaler**<br>
To obtain better results from many machine learning algorithms, it is recommended that the numerical values of the attributes in the dataset have similar magnitudes through scaling.


```python
# information of original set
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 2364 entries, 0 to 2437
    Data columns (total 31 columns):
     #   Column                   Non-Null Count  Dtype  
    ---  ------                   --------------  -----  
     0   avgAnnCount              2364 non-null   float64
     1   avgDeathsPerYear         2364 non-null   int64  
     2   incidenceRate            2364 non-null   float64
     3   medIncome                2364 non-null   int64  
     4   popEst2015               2364 non-null   int64  
     5   povertyPercent           2364 non-null   float64
     6   studyPerCap              2364 non-null   float64
     7   MedianAge                2364 non-null   float64
     8   MedianAgeMale            2364 non-null   float64
     9   MedianAgeFemale          2364 non-null   float64
     10  AvgHouseholdSize         2364 non-null   float64
     11  PercentMarried           2364 non-null   float64
     12  PctNoHS18_24             2364 non-null   float64
     13  PctHS18_24               2364 non-null   float64
     14  PctSomeCol18_24          585 non-null    float64
     15  PctBachDeg18_24          2364 non-null   float64
     16  PctHS25_Over             2364 non-null   float64
     17  PctBachDeg25_Over        2364 non-null   float64
     18  PctEmployed16_Over       2249 non-null   float64
     19  PctUnemployed16_Over     2364 non-null   float64
     20  PctPrivateCoverage       2364 non-null   float64
     21  PctPrivateCoverageAlone  1895 non-null   float64
     22  PctEmpPrivCoverage       2364 non-null   float64
     23  PctPublicCoverage        2364 non-null   float64
     24  PctPublicCoverageAlone   2364 non-null   float64
     25  PctWhite                 2364 non-null   float64
     26  PctBlack                 2364 non-null   float64
     27  PctAsian                 2364 non-null   float64
     28  PctOtherRace             2364 non-null   float64
     29  PctMarriedHouseholds     2364 non-null   float64
     30  BirthRate                2364 non-null   float64
    dtypes: float64(28), int64(3)
    memory usage: 591.0 KB
    


```python
# here: pipeline for train set 

# 'PctSomeCol18_24' has 1420 missing value in train set 
# 'PctPrivateCoverageAlone' has 387 missing value in train set
print(train_rg['PctSomeCol18_24'].isnull().sum())
print(train_rg['PctPrivateCoverageAlone'].isnull().sum())  
```

    1420
    387
    


```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

# create a pipeline
cancer_pipeline = Pipeline([
    ('imputer',SimpleImputer(strategy="median")),  
    ('std_scaler',StandardScaler()) 
])

# pre-process the train set
train_prepared = cancer_pipeline.fit_transform(train_rg) 
```


```python
# check the shape of the pre-processed data
train_prepared.shape
```




    (1891, 31)



# **Exercise 3**

Fit linear regression models to the pre-processed data using: Ordinary least squares (OLS), Lasso and Ridge models. Choose suitable regularisation weights for Lasso and Ridge regression and include a description in text of how they were chosen. In your submitted solution make sure you set the values for the regularisation weights equal to those you identify from your experiment(s). Quantitatively compare your results from all three models and report the best performing one. Include code for all steps above. (10 marks)


# **Sample Answer to Exercise 3**

### 1) OLS Model


```python
# OLS model
from sklearn.linear_model import LinearRegression

# create the ols model
ols_model=LinearRegression()

# fit the model with train set
ols_model.fit(train_prepared, target_rg)
```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>



### 2) Choose suitable regularisation weights for Lasso and Ridge

Choose suitable regularisation weights for Lasso and Ridge regression, we use  functions which are "LassoCV()" and "RidgeCV()" to perform cross-validation and automatically select the optimal regularization weight.
These functions which are LassoCV() and RidgeCV() perform k-fold cross-validation using the Lasso/Ridge algorithm for a range of alpha values, and selects the alpha value that minimizes the mean squared error (MSE) of the cross-validation score. 


```python
import random 
random.seed(123)

from sklearn.linear_model import LassoCV, RidgeCV
from sklearn.model_selection import RepeatedKFold

# Create LassoCV regression model
lasso_model = LassoCV(cv=10)
ridge_model = RidgeCV(cv=10)

# fit model
lasso_model.fit(train_prepared, target_rg)
ridge_model.fit(train_prepared, target_rg)

# extract lambda
print('Optimal alpha for Lasso: %f' % lasso_model.alpha_)
print('Optimal alpha for Ridge: %f' % ridge_model.alpha_)
```

    Optimal alpha for Lasso: 0.031091
    Optimal alpha for Ridge: 10.000000
    

Also, we can use "GridsearchCV" to cross-validation to evaluate the performance of the Lasso/Ridge regression models with different regularization weights. In this case, we have to define the range of the grid. 


```python
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Lasso, Ridge
import numpy as np

# define grid for GridSearchCV
lasso_lambda = dict()
lasso_lambda['alpha'] = np.arange(0, 1, 0.01)

ridge_lambda = dict()
ridge_lambda['alpha'] = np.arange(0.1, 100, 1)

# define search
grid_lasso = GridSearchCV(Lasso(), param_grid=lasso_lambda, scoring='neg_mean_absolute_error', cv=10, n_jobs=-1)
grid_ridge = GridSearchCV(Ridge(), param_grid=ridge_lambda, scoring='neg_mean_absolute_error', cv=10, n_jobs=-1)

# fit the model using the best weight
grid_lasso.fit(train_prepared, target_rg)
grid_ridge.fit(train_prepared, target_rg)

# print the result
print("Optimal alpha for Lasso:", grid_lasso.best_params_)
print("Optimal alpha for Ridge:", grid_ridge.best_params_)
```

    Optimal alpha for Lasso: {'alpha': 0.03}
    Optimal alpha for Ridge: {'alpha': 14.1}
    

#### Summary the Result - alpha for lasso: 0.031091, alpha for ridge: 10.00
To choose the suitable regularisation weights for Lasso and Ridge regression, we use "LassoCV()" and "GridSearchCV()". 
Since "LassoCV()" and "GridSearchCV()" have different approaches to find the optimal hyperparameters, they lead to different result. The primary distinction between LassoCV() and GridSearchCV() is that LassoCV() employs a more efficient algorithm to calculate the solution path over a range of alpha values, while GridSearchCV() conducts a thorough search through a user-defined grid of hyperparameters. In the coursework, we will use the weight from LassoCV()/RidgeCV()<br>

### 3) Evaluate the models

To evaluate those three models, we will perform cross-validation. We will get 10 different scores from each model because we set cv=10 which means 10-fold cross validation. Then, the model will be evaluated through the mean and standard deviation of 10 different scores.


```python
from sklearn.model_selection import cross_val_score

# cross validation to evaluate the model 
ols_scores =cross_val_score(ols_model, train_prepared,target_rg,scoring="neg_mean_squared_error", cv=10)
lasso_scores =cross_val_score(lasso_model, train_prepared,target_rg,scoring="neg_mean_squared_error",cv=10)
ridge_scores =cross_val_score(ridge_model, train_prepared,target_rg,scoring="neg_mean_squared_error",cv=10)

# score the result
def display_scores(scores):
    scores = np.sqrt(-scores)
    print('Scores:',scores)
    print('Mean:',scores.mean())
    print('Standard deviation:',scores.std())
```


```python
display_scores(ols_scores)
```

    Scores: [17.84984992 18.13233717 18.86338505 20.34792811 18.20049619 18.01564056
     21.93261632 20.08231543 17.96716384 18.20863541]
    Mean: 18.96003679964919
    Standard deviation: 1.3026170088140037
    


```python
display_scores(lasso_scores)
```

    Scores: [17.76119305 17.9943221  18.87489733 20.25504555 18.2020003  18.05924887
     21.87449937 20.06557164 17.94640091 18.19989517]
    Mean: 18.923307428421914
    Standard deviation: 1.2941502127256914
    


```python
display_scores(ridge_scores)
```

    Scores: [17.79159463 18.0485983  18.89614497 20.27989288 18.20671343 18.04661432
     21.87180956 20.04523622 17.90873675 18.20287622]
    Mean: 18.929821728533533
    Standard deviation: 1.2910998794188697
    

#### Summary the result
To compare the performance of each model in terms of root mean squared error (RMSE), the negative values of the mean squared error were converted to positive values, and the RMSE was calculated. The mean and standard deviation of the RMSE scores obtained from 10 evaluations were then calculated to compare the models' performance. A smaller mean score indicates better performance.

From the result, there are not big difference between mean score value, but the lasso model's mean score is the smallest at 18.923 among three models, so we can say it has the best performance among the three.

However, it is important to note that this evaluation was conducted on the training set, and as such, it is necessary to evaluate the model's performance on an unseen dataset to ensure its generalizability.

#### Evaluate model performance on unseen test set


```python
from sklearn.metrics import mean_squared_error

# transform test dataset
test_prepared = cancer_pipeline.transform(test_rg)

# (1) ols_model

# prediction
ols_predictions=ols_model.predict(test_prepared)

# evaluate through rmse
final_ols_mse = mean_squared_error(target_test_rg,ols_predictions)
final_ols_rmse = np.sqrt(final_ols_mse)


# (2) lasso_model

lasso_predictions = lasso_model.predict(test_prepared)

final_lasso_mse = mean_squared_error(target_test_rg,lasso_predictions)
final_lasso_rmse = np.sqrt(final_lasso_mse)


# (3) ridge_model

ridge_predictions = ridge_model.predict(test_prepared)

final_ridge_mse = mean_squared_error(target_test_rg,ridge_predictions)
final_ridge_rmse = np.sqrt(final_ridge_mse)
```


```python
# print the result
print(final_ols_rmse, final_lasso_rmse, final_ridge_rmse)
```

    20.180874444966992 20.084560085043606 20.110527170832526
    

### 4) Report the best performing model

It can be concluded that the model with the best performance on the unseen test set is the model with the best generalization ability. While cross-validation on the training set indicated that the Lasso model had the best performance, the true measure of a model's performance is its ability to generalize to new, unseen data. In this case, when the Lasso model was applied to the unseen test data, it produced the lowest RMSE, suggesting that it had the best performance among the models.

# **Exercise 4**

Use Lasso regression and the best regularisation weight identified from Exercise 3 to identify the five most important/relevant features for the provided data set and regression task. Report what these are desceding order of their importance. (5 marks)

#### Explaination
The optimal alpha value for the Lasso model was found to be 0.031091.

In Lasso regression, the magnitude of the coefficients can be used to determine the relative importance of each feature in the model. The features with larger coefficients are considered more important than those with smaller coefficients.

To rank the importance of features, we can sort the absolute values of the coefficients from largest to smallest. The features with the largest absolute coefficients are considered the most important.


```python
# check the alpha of lasso model again
lasso_model.alpha_
```




    0.03109096596016966




```python
# use coefficients to order the importance 
df_importance = pd.Series(abs(lasso_model.coef_), index=train.columns)

# Sort the coefficients in descending order
df_importance = df_importance.sort_values(ascending=False)

# the top 5 most important features
df_importance.head(5)
```




    incidenceRate         11.130159
    PctPrivateCoverage     8.148463
    PercentMarried         7.487670
    avgDeathsPerYear       6.787415
    PctBachDeg25_Over      6.771973
    dtype: float64



# **Exercise 5**

Fit a Random Forest regression model to the training data and quantitatively evaluate and compare the Random Forest regression model with the best linear regression model identified from Exercise 3. Report which model provides the best results. Next, report the top five most important/relevant features for the provided data set and regression task identified using the Random Forest model. Comment on how these compare with the features identified from Lasso regression? (12 marks)

# **Sample Answers for Exercise 5**

### 1) Fit a Random Forest regression model

First, We can use GridSearchCV() to find the optimal hyperparameters for a random forest regression before training the model to the train set. After that, we will calculate the mean RMSE of the model to quantitatively evaluate and compare with other regression models.


```python
from sklearn.ensemble import RandomForestRegressor

# define the model
forest_reg = RandomForestRegressor()

# define the hyperparameter for GridSearchCV
param_grid = {
    'n_estimators': [3, 5, 10, 30],
    'max_features':[2, 4, 6, 8],
    'bootstrap': [False],
    'max_depth': [3, 5, 10],
    'max_features': ['auto', 'sqrt']
}

# perform the grid search to find the optimal hyperparameters for random forest regression model 
grid_forest_reg = GridSearchCV(estimator = forest_reg, param_grid = param_grid, cv=10)

# fit the model to the train set
grid_forest_reg.fit(train_prepared,target_rg)

# print the best hyperparameters found by GridSearchCV
print(grid_forest_reg.best_params_)
```

    {'bootstrap': False, 'max_depth': 10, 'max_features': 'sqrt', 'n_estimators': 30}
    


```python
# perform a cross validation and measure'neg_mean_squared_error' for 10 times
scores_forest_reg =cross_val_score(grid_forest_reg, train_prepared,target_rg,scoring="neg_mean_squared_error",cv=10)

# calculate the mean and standard deviation of 10 different scores
display_scores(scores_forest_reg)
```

    Scores: [17.69232862 19.33195502 18.69092252 22.3404077  18.59979993 17.64658986
     21.274357   21.71336718 19.65909584 18.2907053 ]
    Mean: 19.523952897669503
    Standard deviation: 1.6060271267080348
    

### 2) Model comparison 

In this section, we will compare the random forest regression model with the best linear regression model and report which one provides the best results. We choose the best linear regression model as a lasso as proved in Exercise 3. To compare those two models, we will measure RMSE on unseen test data and compare this value for evaluating the model performance.


```python
# perform predictions on unseen test set
forest_predictions = grid_forest_reg.predict(test_prepared)

final_forest_mse = mean_squared_error(target_test_rg,forest_predictions)
final_forest_rmse = np.sqrt(final_forest_mse)
```


```python
# RMSE for the unseen test set
print(final_lasso_rmse, final_forest_rmse)
```

    20.084560085043606 18.280935448787808
    


```python
# RMSE of cross-validation 
print(display_scores(lasso_scores)) 
print('***************************')
print(display_scores(scores_forest_reg)) 
```

    Scores: [17.76119305 17.9943221  18.87489733 20.25504555 18.2020003  18.05924887
     21.87449937 20.06557164 17.94640091 18.19989517]
    Mean: 18.923307428421914
    Standard deviation: 1.2941502127256914
    None
    ***************************
    Scores: [17.69232862 19.33195502 18.69092252 22.3404077  18.59979993 17.64658986
     21.274357   21.71336718 19.65909584 18.2907053 ]
    Mean: 19.523952897669503
    Standard deviation: 1.6060271267080348
    None
    

#### [ Report the comparison ]

Based on the results of cross-validation with train and validation set, it appears that the Lasso model performed better than random forest regression as it had a smaller mean value. However, when the models predict the unseen test data, the random forest regression model had a smaller RMSE than the Lasso model. This indicates that the random forest regression model performed better on the unseen data, suggesting that it has a better generalization ability.

It is important to note that the results obtained from cross-validation may not always be indicative of a model's performance on unseen data, and thus, evaluating the model's performance on a separate test set is crucial to ensure its generalization ability.

### 3) The top five most important/relevant features


```python
# use .feature_importances_ to check the relevant features to target
forest_importance = grid_forest_reg.best_estimator_.feature_importances_

rf_importance = pd.Series(abs(forest_importance), index=train.columns)

# Sort the feature importance in descending order
rf_importance = rf_importance.sort_values(ascending=False)

# top 5 feature importance from the random forest regression model
rf_importance.head(5)
```




    incidenceRate         0.141942
    PctBachDeg25_Over     0.119470
    medIncome             0.061463
    PctPrivateCoverage    0.056460
    PctHS25_Over          0.054972
    dtype: float64



**how these compare with the features identified from Lasso regression**<br>
From the plot, we can see that feature importances from the lasso model and random forest model are different. This is because calculating the importance of variables can vary depending on the modeling approach used.

The Lasso regression model performs feature selection by shrinking the coefficients of the less important variables to zero, thus selecting only the most important variables for prediction. Therefore, the magnitude of the coefficients that are not set to zero represents the importance of the corresponding variables in the prediction of the target variable. The larger the magnitude of the coefficient, the larger the impact of the corresponding variable on the prediction. Therefore, the Lasso model identifies the most important features by selecting the variables with non-zero coefficients.

On the other hand, the random forest regression model calculates the feature importance based on the decrease in the impurity of the nodes in the trees when the variables are used for splitting. The variables with the highest decrease in impurity are considered to be the most important features for prediction.


```python
lasso_importance = pd.DataFrame(df_importance).head(5)
lasso_importance.reset_index(inplace = True)
forest_importance = pd.DataFrame(rf_importance).head(5)
forest_importance.reset_index(inplace = True)
```


```python
# compare feature importance through bar graphs

import seaborn as sns

fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize=(20,12))

sns.barplot(x='index', y=0, data = forest_importance, ax = axes[0])
axes[0].set_title("Random Forest regression model", fontsize = 20)

#top_feature5 = df_importance.sort_values(ascending=False, by='importance')[:5]
sns.barplot(x='index', y=0, data = lasso_importance , ax = axes[1])
axes[1].set_title("Lasso model", fontsize = 20)
```




    Text(0.5, 1.0, 'Lasso model')




    
![png](output_68_1.png)
    


# **Exercise 6**

Use the provided test example data ('Test_data_example.csv' and 'Test_data_example_targets.csv') to write an inference script to evaluate the best regression model identified from preceding exercises. First re-train the chosen regression model using all of the provided training data and test your predictions on the provided example test data. Note - the final evaluation of your submission will be done by replacing this example test data with held out (unseen) test data that is not provided to you. Use the code snippet provided below to prepare your inference script to predict targets for the unseen test data. (3 marks)


```python
## Read in the provided example test data
test_data_path = data_dir + 'Test_data_example.csv'
test_targets_path = data_dir + 'Test_data_example_targets.csv'

test_data = pd.read_csv(test_data_path)
test_targets = pd.read_csv(test_targets_path)

## Retrain your chosen regression model here 
# For example: lin_reg = LinearRegression()
# lin_reg.fit(X_train,y_train) where X_train and y_train is provided training data
# Next write the lines of code required to predict on unseen test data and evaluate your predictions

```

# **Sample Answers for Exercise 6**

*   Retrain the best regression model identified with best set of associated hyperparameters on the provided training set (1 mark)
*   Write inference script to accept unseen test data as input similar to the provided example test data, predict targets, and evaluate predictions quantitatively using suitable metrics (2 marks)



### 1) retrain the best regression model


```python
# check the best set of hyperparameters 
grid_forest_reg.best_params_
```




    {'bootstrap': False,
     'max_depth': 10,
     'max_features': 'sqrt',
     'n_estimators': 30}




```python
# retrain the model with best parameters on training set
best_regmodel = RandomForestRegressor( **grid_forest_reg.best_params_)
best_regmodel.fit(train_prepared, target_rg)
```




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestRegressor(bootstrap=False, max_depth=10, max_features=&#x27;sqrt&#x27;,
                      n_estimators=30)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestRegressor</label><div class="sk-toggleable__content"><pre>RandomForestRegressor(bootstrap=False, max_depth=10, max_features=&#x27;sqrt&#x27;,
                      n_estimators=30)</pre></div></div></div></div></div>



### 2) Inference script


```python
# provide example test data
test_data_prepared = cancer_pipeline.transform(test_data)

# prediction with test data
final_prediction = best_regmodel.predict(test_data_prepared)

# evaluate predictions quantitatively using suitable metrics

# RMSE
final_mse = mean_squared_error(test_targets, final_prediction)
final_rmse = np.sqrt(final_mse)
print('RMSE:', final_rmse)

# MAE
from sklearn.metrics import mean_absolute_error
final_mae = mean_absolute_error(test_targets, final_prediction)
print('MAE:',final_mae)

# R-squared 
from sklearn.metrics import r2_score
final_r2 = r2_score(test_targets, final_prediction)
print('R-squared:',final_r2)
```

    RMSE: 20.972739845881595
    MAE: 14.939139436039893
    R-squared: 0.4186156110541678
    

# **Classification of 1-year patient mortality following a heart attack**

The provided data set contains data from patients who all suffered heart attacks at some point in the past. Some are still alive and some are not. The data provided contains key clinical information (features) for each patient and the prediction task involves identifying (classifying) which patients are likely to survive for at least one year following the heart attack.
The provided features (clinical variables) to be used as predictors by your classification models include the following:

    1. age-at-heart-attack -- age in years when heart attack occurred
    2. pericardial-effusion -- binary. Pericardial effusion is fluid
			      around the heart.  0=no fluid, 1=fluid
    3. fractional-shortening -- a measure of contracility around the heart
			       lower numbers are increasingly abnormal
    4. epss -- E-point septal separation, another measure of contractility.  
	      Larger numbers are increasingly abnormal.
    5. lvdd -- left ventricular end-diastolic dimension.  This is
	      a measure of the size of the heart at end-diastole.
	      Large hearts tend to be sick hearts.

    6. wall-motion-index -- equals wall-motion-score divided by number of
			   segments seen.  Usually 12-13 segments are seen
			   in an echocardiogram.  
               
The target variable is encoded as a binary outcome of whether a patient survived for 1 year post-heart attack or not. Label '0' indicates that the patient died within one year of a heart attack. Label '1' indicates that the patient survived for at least one year after a heart attack.

# **Exercise 7**

Read in the provided data set for classification of patients at risk of mortality 1-yr post heart attack. Plot histograms of all features to visualise their distributions and identify outliers. Report identified outliters and take steps to deal with outliers (if any) appropriately (3 marks)


```python
root_dir = './' # this is to be defined by you 
local_path = 'Data-for-students-classification/' # store the related data files in this folder
data_dir = root_dir + local_path

data_features_path = data_dir + 'Heart-attack-data-predictors.csv'
data_targets_path = data_dir + 'Heart-attack-data-targets.csv'
```


```python
# read the training and targets files
train_class = pd.read_csv(data_features_path)
target_class = pd.read_csv(data_targets_path)
```


```python
train_class.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 131 entries, 0 to 130
    Data columns (total 6 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   AgeAtHeartAttack      126 non-null    float64
     1   PericardialEffusion   131 non-null    int64  
     2   FractionalShortening  124 non-null    float64
     3   epss                  117 non-null    float64
     4   lvdd                  121 non-null    float64
     5   WallMotionIndex       130 non-null    float64
    dtypes: float64(5), int64(1)
    memory usage: 6.3 KB
    

### 1) Plot the histograms


```python
# plot histogram for all features from train_class 
train_class.hist(bins=50,figsize=(20,15))

# plot histogram for target 
target_class.hist(bins=50,figsize=(12,8))
# we can see that the target data is imbalanced
```




    array([[<AxesSubplot:title={'center':'Target-class'}>]], dtype=object)




    
![png](output_83_1.png)
    



    
![png](output_83_2.png)
    


### 2) Report identified outliers

An outlier is a very small or large value that is usually far from the range of observed data. Outlier processing is essential because these outliers can have a significant impact on decision making.

**(1) Data Outlier Detection**<br>

There are two commonly used ways to detect outliers. 

- histogram : From the histogram, outliers lie outside the overall pattern of distribution. Since outliers are values much larger or smaller than most data, the bar much higher or shorter than other bars can indicate outliers. 
- boxplot : From the boxplot, outliers are outside the "whiskers" of the boxplot. Values that lie outside the whiskers can be considered outliers. Data smaller than (Q1 – 1.5 * IQR) or larger than (Q3 + 1.5 * IQR) are treated as outliers.

**(2) Dealing with Outliers**<br>

When it comes to dealing with outliers, it is important to choose the right feature and the number of outliers going to be removed. Specificially, the feature that is relevant to target value is firstly considered, and if the dataset is small, we need to consider proper way to deal with outliers not just removing them. 

- remove outliers : Removing the values that are treated as outliers in histogram and boxplot. It's the most common way to deal with outliers, but it can be not appropriate when the dataset is small. 
- rescaling : Rescaling such as standardisation can reduce the impact of outliers on the overall distribution of the data. It can make the distribution of the data more compact and symmetric, which can make it easier to identify and handle outliers. 

**(3) Plan for dealing with outliers**<br>

In this coursework, from the histogram, a features which is 'WallMotionIndex' seems to have outliers. This is due to the presence of bars that are outside the expected range in a normal distribution.It can be seen that standardization cannot solve the outlier problem for this feature, so it will be handled following steps.
   * Step 1) Generate dataset for the boxplot 
   * Step 2) Create the boxplot 
   * Step 3) Make function to find out outlier index
   * Step 4) Drop outliers
   * Step 5) Check the result


```python
# step1) concat input and output dataset for plotting the boxplot
outlier_df = pd.concat([train_class, target_class], axis = 1)
outlier_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AgeAtHeartAttack</th>
      <th>PericardialEffusion</th>
      <th>FractionalShortening</th>
      <th>epss</th>
      <th>lvdd</th>
      <th>WallMotionIndex</th>
      <th>Target-class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>71.0</td>
      <td>0</td>
      <td>0.260</td>
      <td>9.000</td>
      <td>4.600</td>
      <td>1.00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>72.0</td>
      <td>0</td>
      <td>0.380</td>
      <td>6.000</td>
      <td>4.100</td>
      <td>1.70</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>55.0</td>
      <td>0</td>
      <td>0.260</td>
      <td>4.000</td>
      <td>3.420</td>
      <td>1.00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>60.0</td>
      <td>0</td>
      <td>0.253</td>
      <td>12.062</td>
      <td>4.603</td>
      <td>1.45</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>57.0</td>
      <td>0</td>
      <td>0.160</td>
      <td>22.000</td>
      <td>5.750</td>
      <td>2.25</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# step2) Create the boxplot 

# To check the details, histogram and box plot
fig, axes = plt.subplots(nrows = 1, ncols = 3, figsize=(20,8))

train_class['WallMotionIndex'].hist(ax = axes[0], bins=50)
axes[0].set_title("Histogram of WallMotionIndex", fontsize = 20)

#sns.boxplot(x='Target-class', y = 'WallMotionIndex', data = outlier_df)
sns.boxplot(y = 'WallMotionIndex', data = outlier_df, ax=axes[1])
axes[1].set_title('Boxplot of WallMotionIndex', fontsize = 20)

sns.boxplot(x='Target-class', y = 'WallMotionIndex', data = outlier_df)
axes[2].set_title('Target vs WallMotionIndex', fontsize = 20)
```




    Text(0.5, 1.0, 'Target vs WallMotionIndex')




    
![png](output_86_1.png)
    



```python
# step3) make function to find out outlier index
# there are outliers in class 0, so ['Target-class'] is set to '0'

def remove_outlier(input_data, column):
    input_data = input_data[input_data['Target-class']==0][column]
    quan_25 = np.percentile(input_data.values, 25)
    quan_75 = np.percentile(input_data.values, 75)
    
    IQR =  quan_75 - quan_25
    IQR = IQR * 1.5
    
    lowest = quan_25 - IQR
    highest = quan_75 + IQR
    outlier_index = input_data[(input_data < lowest) | (input_data > highest)].index
    
    print(len(outlier_index))
    
    return outlier_index

remove_outlier(outlier_df, 'WallMotionIndex')
```

    6
    




    Int64Index([4, 41, 45, 57, 73, 110], dtype='int64')




```python
# step 4) drop outliers
outlier_index = [4, 41, 45, 57, 73, 110]
outlier_df.drop(outlier_index, axis = 0, inplace = True)
outlier_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AgeAtHeartAttack</th>
      <th>PericardialEffusion</th>
      <th>FractionalShortening</th>
      <th>epss</th>
      <th>lvdd</th>
      <th>WallMotionIndex</th>
      <th>Target-class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>71.0</td>
      <td>0</td>
      <td>0.260</td>
      <td>9.000</td>
      <td>4.600</td>
      <td>1.00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>72.0</td>
      <td>0</td>
      <td>0.380</td>
      <td>6.000</td>
      <td>4.100</td>
      <td>1.70</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>55.0</td>
      <td>0</td>
      <td>0.260</td>
      <td>4.000</td>
      <td>3.420</td>
      <td>1.00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>60.0</td>
      <td>0</td>
      <td>0.253</td>
      <td>12.062</td>
      <td>4.603</td>
      <td>1.45</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>68.0</td>
      <td>0</td>
      <td>0.260</td>
      <td>5.000</td>
      <td>4.310</td>
      <td>1.00</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# step 5) check the result
fig, axes = plt.subplots(figsize = (12,8))
sns.boxplot(x='Target-class', y = 'WallMotionIndex', data = outlier_df)
```




    <AxesSubplot:xlabel='Target-class', ylabel='WallMotionIndex'>




    
![png](output_89_1.png)
    



```python
# remove outliers from the original dataset

# 1) Target dataset: target_class
target_class.drop(outlier_index, axis = 0, inplace = True)

# 2) Feature dataset: train_class
train_class.drop(outlier_index, axis = 0, inplace = True)
```


```python
# reset index because we removed outliers (this is needed for StratifiedShuffleSplit)
target_class.reset_index(inplace = True, drop= True)
train_class.reset_index(inplace = True, drop = True)
```

# **Exercise 8**

Create a machine learning pipeline using scikit-learn and pre-process the provided data appropriately (3 marks)

### 1) Split the dataset 
Split the dataset into train and test. The train set is for training the model, and the test set is for evaluating the model's performance and gerneralibility. In this coursework, binary variable which is PericardialEffusion and target variable is unbalanced so we will use 'StratifiedShuffleSplit'. This method splits the dataset into training and test sets while ensuring that the class distribution of the unbalance category variable is maintained in both sets.

#### Before split the dataset


```python
# check the percentage of each class (PericardialEffusion)
train_class['PericardialEffusion'].value_counts() /len(train_class)
```




    0    0.816
    1    0.184
    Name: PericardialEffusion, dtype: float64




```python
# check the percentage of each class (PericardialEffusion)
target_class['Target-class'].value_counts() /len(target_class)
```




    0    0.688
    1    0.312
    Name: Target-class, dtype: float64




```python
# split the data into training and test set
from sklearn.model_selection import StratifiedShuffleSplit

split = StratifiedShuffleSplit(n_splits=1, test_size=0.2,random_state=42) 

for train_index, test_index in split.split(train_class,train_class["PericardialEffusion"]):
    strat_train_set = train_class.loc[train_index]
    strat_test_set = train_class.loc[test_index]
```


```python
# split the target dataset as well
target_train = target_class.loc[train_index]
target_test = target_class.loc[test_index]
```

#### After split the dataset


```python
# check the percentage of each class after StratifiedShuffleSplit
# It appears that they maintain the percentage of each class from the original dataset

print(strat_train_set['PericardialEffusion'].value_counts() /len(strat_train_set))
print(strat_test_set['PericardialEffusion'].value_counts() /len(strat_test_set))

print(target_train['Target-class'].value_counts() /len(target_train))
print(target_test['Target-class'].value_counts() /len(target_test))
```

    0    0.82
    1    0.18
    Name: PericardialEffusion, dtype: float64
    0    0.8
    1    0.2
    Name: PericardialEffusion, dtype: float64
    0    0.69
    1    0.31
    Name: Target-class, dtype: float64
    0    0.68
    1    0.32
    Name: Target-class, dtype: float64
    

### 2) Pipeline plan

**- Missing value**<br>
Missing values will be replaced by the median. Since the imputer can calculate numerical value, we will drop "PericardialEffusion" temporary. 
This is because, in the case of binary features, there is a possibility that missing values may be imputed with the more frequent class. Also, when it is replaced with the mean, the missing values may be filled with a value between 0 and 1 instead of binary values. In the current data, there are no missing values in the "PericardialEffusion" column.

**- Scaler**<br>
To obtain better results from many machine learning algorithms, it is recommended that the numerical values of the attributes in the dataset have similar magnitudes.


```python
# drop the binary feature temporarly
train_class_num = strat_train_set.drop("PericardialEffusion",axis=1)
num_attribs = list(train_class_num)
bin_attribs=["PericardialEffusion"]
```


```python
from sklearn.base import BaseEstimator

# select only numerical attributes
class DataFrameSelector(BaseEstimator):
    
    def __init__(self, attribute_names):
        self.attribute_names= attribute_names
        
    def fit(self,X, y = None):
        return self
    
    def transform(self, X):
        return X[self.attribute_names].values 
```


```python
num_pipeline= Pipeline([
    ('selector', DataFrameSelector(num_attribs)),
    ('imputer',SimpleImputer(strategy="median")),
    ('std_scaler',StandardScaler())
])

bin_pipeline = Pipeline([
    ('selector',DataFrameSelector(bin_attribs))
])
```


```python
from sklearn.pipeline import FeatureUnion

full_pipeline = FeatureUnion(transformer_list=[
    ("num_pipeline",num_pipeline),
    ("bin_pipeline",bin_pipeline)
])
```


```python
class_prepared = full_pipeline.fit_transform(strat_train_set)
```


```python
class_prepared.shape
```




    (100, 6)



# **Exercise 9**

Train logistic regression classifiers, with and without L1 and L2 regularisation, using the provided data and compare and evaluate their performance. Report the best performing classifier, with supporting evidence/justification for why it was identified as the best performing classifier. (14 marks)

### 1) Logistic Regression Classifiers with and without L1 and L2


```python
from sklearn.linear_model import LogisticRegression

# logistic regression without regularisation
log_model = LogisticRegression(penalty='none')

# fit the model 
log_model.fit(class_prepared, target_train)
```




<style>#sk-container-id-3 {color: black;background-color: white;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(penalty=&#x27;none&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" checked><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(penalty=&#x27;none&#x27;)</pre></div></div></div></div></div>




```python
# logistic regression with l1, l2
log_lasso = LogisticRegression(penalty='l1', solver='liblinear') 
log_ridge = LogisticRegression(penalty='l2', solver='liblinear')
```

### 2) Cross validation to find out the best parameter for regularization model
Since the models that we created above don't have the best parameter, we will find out the best parameters through K-fold cross-validation.

When each class has a different proportion in the dataset, it's important to use "stratified sampling" during cross-validation to ensure that each fold has the same proportion of each class as the original dataset. Since "PericardialEffusion" has a certain proportion of each class, we try to maintain that proportion in the cross-validation otherwise we will get bad classification results for the minority class. The scikit-learn library provides a StratifiedShuffleSplit class that can be used for this purpose. 

Additionally, the dataset size is insufficient, so n_splits was increased to 25. (from the previous exercise, it was 10)


```python
# hyperparameter tuning for l1, l2

# try to maintatin the proportion of binary variable
cv_class = StratifiedShuffleSplit(n_splits=25, test_size=0.2, random_state=42)

# make function to hyperparameter tuning
def hyper_tuning(model, X, y, params):
        
    # Grid Search
    grid = GridSearchCV(model, params, scoring = 'accuracy', cv = cv_class)
    # train the model
    grid.fit(X, y)
    
    print('best parameter:', grid.best_params_)
    print('best score:', grid.best_score_)
    
    return grid.best_estimator_
```


```python
# parameter for each model
param_l1 = {'C': [0.001, 0.01, 0.1, 0.125, 0.15, 0.5,1,10], 'max_iter': [100,300,500]}
param_l2 = {'C': [0.001, 0.01, 0.1, 0.125, 0.15, 0.5,1,10, 100], 'max_iter': [100,300, 500]}
```


```python
# lasso best parameters
log_lasso = hyper_tuning(log_lasso,class_prepared, target_train, params = param_l1)

# fit with the best parameters
log_lasso.fit(class_prepared, target_train)
```

    best parameter: {'C': 0.5, 'max_iter': 100}
    best score: 0.7759999999999999
    




<style>#sk-container-id-4 {color: black;background-color: white;}#sk-container-id-4 pre{padding: 0;}#sk-container-id-4 div.sk-toggleable {background-color: white;}#sk-container-id-4 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-4 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-4 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-4 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-4 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-4 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-4 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-4 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-4 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-4 div.sk-item {position: relative;z-index: 1;}#sk-container-id-4 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-4 div.sk-item::before, #sk-container-id-4 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-4 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-4 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-4 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-4 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-4 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-4 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-4 div.sk-label-container {text-align: center;}#sk-container-id-4 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-4 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(C=0.5, penalty=&#x27;l1&#x27;, solver=&#x27;liblinear&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" checked><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(C=0.5, penalty=&#x27;l1&#x27;, solver=&#x27;liblinear&#x27;)</pre></div></div></div></div></div>




```python
# ridge best parameters
log_ridge = hyper_tuning(log_ridge,class_prepared, target_train, params = param_l2)

# fit with the best parameters
log_ridge.fit(class_prepared, target_train)
```

    best parameter: {'C': 0.125, 'max_iter': 100}
    best score: 0.7819999999999999
    




<style>#sk-container-id-5 {color: black;background-color: white;}#sk-container-id-5 pre{padding: 0;}#sk-container-id-5 div.sk-toggleable {background-color: white;}#sk-container-id-5 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-5 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-5 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-5 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-5 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-5 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-5 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-5 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-5 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-5 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-5 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-5 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-5 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-5 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-5 div.sk-item {position: relative;z-index: 1;}#sk-container-id-5 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-5 div.sk-item::before, #sk-container-id-5 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-5 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-5 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-5 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-5 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-5 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-5 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-5 div.sk-label-container {text-align: center;}#sk-container-id-5 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-5 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-5" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(C=0.125, solver=&#x27;liblinear&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" checked><label for="sk-estimator-id-5" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(C=0.125, solver=&#x27;liblinear&#x27;)</pre></div></div></div></div></div>



### 3) Evaluate and Compare the models

To compare the performance of three classification models using multiple evaluation metrics, such as accuracy, ROC AUC, recall, F1-score, and precision, we can perform cross-validation with train set through cross_validate() function. 

cross_validate() is a function provided by scikit-learn that performs cross-validation and returns the evaluation scores for each fold and metric. We can use this function to evaluate the performance and compare their results across multiple metrics.

Also, we will evaluate the models with unseen test set to evaluate their generalizability.

- **Cross validation on train set**

The table shows the evaluation metrics for three different models, namely Logistic Regression, Lasso, and Ridge.

To determine the best-performing model, it is essential to consider the evaluation metrics that are most relevant to the specific problem at hand. The choice of the relevant metric may vary depending on the context and the nature of the problem being addressed. For instance, if the goal is to minimize false positives, 'precision' is more critical, whereas if the focus is on reducing false negatives, 'recall' becomes more important. In general, higher values for accuracy, ROC-AUC score, recall, F1 score, and precision are indicative of better performance, but the relative importance of each metric may vary depending on the specific problem.

In this analysis, firstly, we will consider accuracy. Looking at the result table, we can see that the Ridge model has the highest testing accuracy (0.782), followed closely by Lasso (0.776) and Logistic Regression (0.774). Also, the Ridge model also has the highest testing ROC-AUC score (0.802857). 

Moreover, compared to the model without the regularization, the ridge model shows a small difference between the train accuracy (0.79) and test(validation) accuracy (0.78), suggesting that the model did not overfit to the training data.


Therefore, based on the cross-validation, we can conclude that the Ridge model performs the best among the three models.


```python
# generate cross-validation generator
cv_class = StratifiedShuffleSplit(n_splits=25, test_size=0.2, random_state=42)

# Cross validation
from sklearn.model_selection import cross_validate

cross_score_log = cross_validate(log_model, class_prepared, target_train, 
               scoring=['accuracy', 'roc_auc', 'recall', 'f1', 'precision'], 
               return_train_score=True, cv=cv_class)

cross_score_l1 = cross_validate(log_lasso, class_prepared, target_train, 
               scoring=['accuracy', 'roc_auc', 'recall', 'f1', 'precision'], 
               return_train_score=True, cv=cv_class)

cross_score_l2 = cross_validate(log_ridge, class_prepared, target_train, 
               scoring=['accuracy', 'roc_auc', 'recall', 'f1', 'precision'], 
               return_train_score=True, cv=cv_class)
```


```python
# for the train data 
score_list = [cross_score_log, cross_score_l1, cross_score_l2 ]
mean_score = {}

for i, score in enumerate(score_list):
    
    key = ['Logistic', 'Lasso', 'Ridge']
    
    mean_acc = score['train_accuracy'].mean()
    mean_roc = score['train_roc_auc'].mean()
    mean_recall = score['train_recall'].mean()
    mean_f1 = score['train_f1'].mean()
    mean_precision = score['train_precision'].mean()
    
    
    mean_score[key[i]] = mean_acc, mean_roc, mean_recall, mean_f1, mean_precision

df_train = pd.DataFrame(mean_score,  index = ['tr_accuracy','tr_roc_auc', 'tr_recall','tr_f1','tr_precision'])
```


```python
# for the validation data
score_list = [cross_score_log, cross_score_l1, cross_score_l2 ]
mean_score2 = {}

for i, score in enumerate(score_list):
    
    key = ['Logistic', 'Lasso', 'Ridge']
    
    mean_acc = score['test_accuracy'].mean()
    mean_roc = score['test_roc_auc'].mean()
    mean_recall = score['test_recall'].mean()
    mean_f1 = score['test_f1'].mean()
    mean_precision = score['test_precision'].mean()
    
    
    mean_score[key[i]] = mean_acc, mean_roc, mean_recall, mean_f1, mean_precision

df_valid = pd.DataFrame(mean_score,  index = ['te_accuracy','te_roc_auc', 'te_recall','te_f1','te_precision'])
```


```python
# final result
df_train, df_valid
```




    (              Logistic     Lasso     Ridge
     tr_accuracy   0.815000  0.803000  0.796000
     tr_roc_auc    0.829353  0.813149  0.819607
     tr_recall     0.588800  0.550400  0.553600
     tr_f1         0.664682  0.634826  0.628281
     tr_precision  0.765824  0.753003  0.729501,
                   Logistic     Lasso     Ridge
     te_accuracy   0.774000  0.776000  0.782000
     te_roc_auc    0.797619  0.800476  0.802857
     te_recall     0.533333  0.526667  0.540000
     te_f1         0.565615  0.565019  0.577555
     te_precision  0.654032  0.659937  0.672801)



- **Predict on test set**<br>
The given numbers represent the evaluation metrics(accuracy, confusion matrix, ROC-AUC) of three different models (Logistic, Lasso, and Ridge) on an unseen test dataset.

**Accuracy** : The accuracy metric measures the proportion of correctly classified samples out of the total number of samples in the test set. The numbers show that the Ridge model has the highest accuracy of 0.8, followed by Logistic and Lasso with the same accuracy of 0.76.

**Confusion Matrix** : When all models have the same accuracy, using the confusion matrix to select the best model will be different depending on the context of the use. In my view, it is important to predict the patient who will die within a year of a heart attack because patients can get help to take preventive measures if health professionals can predict this. Therefore, Ridge model is the best from the confusion matrix. Also, the ridge model has the highest precision (0.8)

**ROC-AUC** : The ROC-AUC score measures the model's ability to distinguish between positive and negative classes by calculating the area under the receiver operating characteristic (ROC) curve. The numbers show that the Ridge model has the highest ROC-AUC score of 0.72, followed by Logistic and Lasso with the same ROC-AUC score of 0.69.


```python
# pre-processed test set
class_test_prepared = full_pipeline.transform(strat_test_set)
```


```python
# prediction 
log_predictions=log_model.predict(class_test_prepared)
lasso_predictions=log_lasso.predict(class_test_prepared)
ridge_predictions=log_ridge.predict(class_test_prepared)
```


```python
# (1) Accuracy 

from sklearn.metrics import *

acc_log = accuracy_score(target_test, log_predictions)
acc_lasso = accuracy_score(target_test, lasso_predictions)
acc_ridge = accuracy_score(target_test, ridge_predictions)

print('Logistic accuracy:', acc_log,'Lasso accuracy:',acc_lasso,'Ridge accuracy:',acc_ridge)
```

    Logistic accuracy: 0.76 Lasso accuracy: 0.76 Ridge accuracy: 0.8
    


```python
# (2) Confusion Matrix

from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# compute the confusion matrix for logistic regression without regulation
cm_log = confusion_matrix(target_test, log_predictions)

# compute the confusion matrix for the logistic regression with lasso
cm_lasso = confusion_matrix(target_test, lasso_predictions)

# compute the confusion matrix for the logistic regression with lasso
cm_ridge = confusion_matrix(target_test, ridge_predictions)

# plot the confusion matrix for logistic regression without regulation
sns.heatmap(cm_log, annot=True, fmt='d', cmap='Blues')
plt.title('Logistic Regression Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# plot the confusion matrix for the lasso classifier
sns.heatmap(cm_lasso, annot=True, fmt='d', cmap='YlOrBr')
plt.title('Lasso Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# plot the confusion matrix for the ridge classifier
sns.heatmap(cm_ridge, annot=True, fmt='d', cmap='Greens')
plt.title('Ridge Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

```


    
![png](output_127_0.png)
    



    
![png](output_127_1.png)
    



    
![png](output_127_2.png)
    



```python
# (3) ROC curve

from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

log_fpr, log_tpr, _ = roc_curve(target_test, log_predictions)
lasso_fpr, lasso_tpr, _ = roc_curve(target_test, lasso_predictions)
ridge_fpr, ridge_tpr, _ = roc_curve(target_test, ridge_predictions)

# Calculate the area under the ROC curve for each model
log_auc = auc(log_fpr, log_tpr)
lasso_auc = auc(lasso_fpr, lasso_tpr)
ridge_auc = auc(ridge_fpr, ridge_tpr)

# Plot the ROC curves for each model
plt.plot(log_fpr, log_tpr, label='Logistic Regression (AUC = %0.2f)' % log_auc)
plt.plot(lasso_fpr, lasso_tpr, label='Lasso Regression (AUC = %0.2f)' % lasso_auc)
plt.plot(ridge_fpr, ridge_tpr, label='Ridge Regression (AUC = %0.2f)' % ridge_auc)

# Add labels, title, and legend to the plot
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()

# Show the plot
plt.show()

```


    
![png](output_128_0.png)
    


- **Report the best performing classifier**

From the prediction on the unseen test set, the Ridge model appears to be the best-performing classifier among the three models, with the highest accuracy (0.8) and the highest ROC-AUC score (0.72). Moreover, considering the importance of identifying patients who are at risk of dying within a year of a heart attack, the Ridge model is also the best option, as per the interpretation of the confusion matrix. Therefore, the Ridge model is likely the best choice among these three models.

# **Exercise 10**

Train a Random Forest classifier using the provided data and quantitatively evaluate and compare the Random Forest classifier  with the best logistic regression classifier identified from Exercise 9. Report which model provides the best results. Next, report the top five most important/relevant features identified using the Random Forest model. (10 marks)

### 1) Train a Random Forest classifier 

There are two commonly used way to find the hyperparameters of random forest classifier which are 'GridSearchCV' and 'RandomizedSearchCV'.

GridSearchCV performs an exhaustive search over a predefined hyperparameter grid, testing all possible combinations of hyperparameters. It evaluates the performance of the model on each combination using cross-validation and returns the combination of hyperparameters that produces the best performance.

On the other hand, RandomizedSearchCV performs a randomized search over a predefined hyperparameter space, testing a random subset of hyperparameter combinations. It randomly samples the hyperparameters from a distribution and evaluates the performance of the model on each combination using cross-validation. The number of combinations to try is controlled by the n_iter parameter.

In this case, GridSearchCV is used because it guarantees that all combinations of hyperparameters will be tried, which can be helpful in finding the optimal set of hyperparameters when the search space is well-defined. Also, it is not time-consuming because the hyperparameter space is not large and the dataset is not too large.



```python
# define the hyperparameters
params = { 'n_estimators' : [5, 20, 50, 70, 100],
           'max_depth' : [4, 6, 8, 10, 12, 18],
           'min_samples_leaf' : [2, 4, 8, 10],
           'min_samples_split' : [4, 8, 10],
           'max_features':[2,3,4]
            }
```


```python
# GridSearchCV 
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

# generate the randomforest 
forest_class = RandomForestClassifier()

# generate cross-validation generator
# Since the dataset is small, increase n_splits from 10 to 25 for cross validation here
cv_class = StratifiedShuffleSplit(n_splits=25, test_size=0.2, random_state=42)

# GridSearchCV
grid_cv = GridSearchCV(forest_class, param_grid = params, cv = cv_class, n_jobs= -1, verbose = 1, scoring = 'accuracy')
grid_cv.fit(class_prepared, target_train)
```

    Fitting 25 folds for each of 1080 candidates, totalling 27000 fits
    




<style>#sk-container-id-6 {color: black;background-color: white;}#sk-container-id-6 pre{padding: 0;}#sk-container-id-6 div.sk-toggleable {background-color: white;}#sk-container-id-6 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-6 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-6 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-6 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-6 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-6 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-6 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-6 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-6 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-6 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-6 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-6 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-6 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-6 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-6 div.sk-item {position: relative;z-index: 1;}#sk-container-id-6 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-6 div.sk-item::before, #sk-container-id-6 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-6 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-6 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-6 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-6 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-6 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-6 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-6 div.sk-label-container {text-align: center;}#sk-container-id-6 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-6 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-6" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=StratifiedShuffleSplit(n_splits=25, random_state=42, test_size=0.2,
            train_size=None),
             estimator=RandomForestClassifier(), n_jobs=-1,
             param_grid={&#x27;max_depth&#x27;: [4, 6, 8, 10, 12, 18],
                         &#x27;max_features&#x27;: [2, 3, 4],
                         &#x27;min_samples_leaf&#x27;: [2, 4, 8, 10],
                         &#x27;min_samples_split&#x27;: [4, 8, 10],
                         &#x27;n_estimators&#x27;: [5, 20, 50, 70, 100]},
             scoring=&#x27;accuracy&#x27;, verbose=1)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" ><label for="sk-estimator-id-6" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=StratifiedShuffleSplit(n_splits=25, random_state=42, test_size=0.2,
            train_size=None),
             estimator=RandomForestClassifier(), n_jobs=-1,
             param_grid={&#x27;max_depth&#x27;: [4, 6, 8, 10, 12, 18],
                         &#x27;max_features&#x27;: [2, 3, 4],
                         &#x27;min_samples_leaf&#x27;: [2, 4, 8, 10],
                         &#x27;min_samples_split&#x27;: [4, 8, 10],
                         &#x27;n_estimators&#x27;: [5, 20, 50, 70, 100]},
             scoring=&#x27;accuracy&#x27;, verbose=1)</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-8" type="checkbox" ><label for="sk-estimator-id-8" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
# check the best parameter combination and its accuracy
print('best parameter: ', grid_cv.best_params_)
print('best accuracy: {:.4f}'.format(grid_cv.best_score_))
```

    best parameter:  {'max_depth': 4, 'max_features': 3, 'min_samples_leaf': 2, 'min_samples_split': 8, 'n_estimators': 100}
    best accuracy: 0.7880
    


```python
# define the random forest classifier with the best parameters combination from GridSearchCV
rf_final = RandomForestClassifier( **grid_cv.best_params_)

# retrain it 
rf_final.fit(class_prepared, target_train)
```




<style>#sk-container-id-9 {color: black;background-color: white;}#sk-container-id-9 pre{padding: 0;}#sk-container-id-9 div.sk-toggleable {background-color: white;}#sk-container-id-9 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-9 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-9 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-9 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-9 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-9 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-9 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-9 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-9 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-9 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-9 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-9 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-9 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-9 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-9 div.sk-item {position: relative;z-index: 1;}#sk-container-id-9 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-9 div.sk-item::before, #sk-container-id-9 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-9 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-9 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-9 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-9 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-9 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-9 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-9 div.sk-label-container {text-align: center;}#sk-container-id-9 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-9 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-9" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(max_depth=4, max_features=3, min_samples_leaf=2,
                       min_samples_split=8)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-11" type="checkbox" checked><label for="sk-estimator-id-11" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier(max_depth=4, max_features=3, min_samples_leaf=2,
                       min_samples_split=8)</pre></div></div></div></div></div>



### 2) Evaluate the model

To evaluate the performance of the random forest classifier, we will take two approaches. Firstly, we will perform cross-validation on the training set by splitting them into train and validation sets automatically using 'cross_validate'. Then, we will measure the mean of accuracy and ROC-AUC. Secondly, we will make predictions on an unseen test set to evaluate the generalizability of the model.


```python
# (1) Evaluate the model using cross validation with train set
random.seed(123)

rf_final_score = cross_validate(rf_final, class_prepared, target_train, 
               scoring=['accuracy', 'roc_auc', 'precision'],
               return_train_score=True, cv=cv_class)


print('Train set')
print(rf_final_score['train_accuracy'].mean()) 
print(rf_final_score['train_roc_auc'].mean())
print(rf_final_score['train_precision'].mean())

print('Valid set')
print(rf_final_score['test_accuracy'].mean()) 
print(rf_final_score['test_roc_auc'].mean()) 
print(rf_final_score['test_precision'].mean())
```

    Train set
    0.8735
    0.9714327272727273
    0.9751692466460269
    Valid set
    0.78
    0.7114285714285715
    0.7414285714285714
    


```python
# (2) Evaluate the model with predicting on unseen test set

# make a prediction
rf_predictions = rf_final.predict(class_test_prepared)

# measure the accuracy for test set
acc_rf = accuracy_score(target_test, rf_predictions)
acc_rf
```




    0.72




```python
# (3) confusion matrix of prediction on the unseen test set
cm_rf = confusion_matrix(target_test, rf_predictions)

# plot the confusion matrix 
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Blues')
plt.title('Random Forest Classifier Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()
```


    
![png](output_139_0.png)
    


**Interpretation of confusion matrix**<br>
We can recognise how many of the model's predictions were correct or not and where mistakes were made. In this context, it is more critical to reduce false positives, which occur when the model predicts that a patient will survive for more than a year, but actually die within a year. This is because it helps patients to improve their chances of survival. Since we want to minimize FP, we can calculate 'precision' and improve this.


```python
# (4) ROC-AUC on unseen test set
rf_fpr, rf_tpr, _ = roc_curve(target_test, rf_predictions)

# Calculate the area under the ROC curve 
rf_auc = auc(rf_fpr, rf_tpr)

# Plot the ROC curves for each model
plt.plot(rf_fpr, rf_tpr, label='Random Forest Classifier (AUC = %0.2f)' % rf_auc)
rf_auc
```




    0.5955882352941176




    
![png](output_141_1.png)
    


**Interpretation of ROC-AUC**<br>
In general, an AUC score closer to 1 indicates better model performance, while a score closer to 0.5 suggests poorer performance. 
For this model, an AUC score that is more close to 0.5 suggests that the model has some predictive power, but its performance may be relatively weak.

### 3) Compare the Random Forest classifier with the ridge regression classifier

Cross-validation is commonly used to compare multiple models. From the cross validation(above), the mean accuracy of ridge model was 0.78, and the random forest model was 0.77 for the validation set. Also, we will compare those two models using the results of predicting on an unseen test set, focusing on the following evaluation metrics: accuracy, AUC, and confusion matrix. Predicting a test set helps to estimate the actual generalization error.

**1. Accuracy**<br>
The accuracy of ridge model is 0.8, and the random forest classifier is also 0.72 for the unseen test set.

**2. Confusion Matrix**<br>
We can estimate overall sense of performance using confusion matrix. If they have similar or the same accuracy, the best model would be different depending on the context. In this case, since reducing FP is the most important, we can calculate and compare their precision. The precision for ridge is higher than random forest classifier.

**3.ROC-AUC**<br>
An ROC-AUC score of 0.5 represents a model that performs no better than random guessing, while a score of 1.0 represents a perfect model that correctly classifies all instances. The ridge model achieved a ROC-AUC score of 0.72, which indicates that it performed moderately at distinguishing between the positive and negative classes. Also, the random forest model achieved a ROC-AUC score of 0.72, which indicates that it performed same with the ridge model when it comes to roc-auc.

**4.Limitations**<br>
Based on my personal understanding, the size of the test set is too small, so it is difficult to reliably estimate the performance of the models and to generalize the results. 


```python
# (1) Accuracy 
print('Accuracy of Ridge Model:', acc_ridge)
print('Accuracy of Random forest classifier:', acc_rf)
```

    Accuracy of Ridge Model: 0.8
    Accuracy of Random forest classifier: 0.72
    


```python
# (2) Confusion Matrix

# ridge confusion matrix
cm_ridge = confusion_matrix(target_test, ridge_predictions)
sns.heatmap(cm_ridge, annot=True, fmt='d', cmap='Greens')
plt.title('Ridge Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# random forest confusion matrix
cm_rf = confusion_matrix(target_test, rf_predictions)

# plot the confusion matrix 
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Blues')
plt.title('Random Forest Classifier Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()
```


    
![png](output_145_0.png)
    



    
![png](output_145_1.png)
    



```python
# (3) ROC-AUC

plt.plot(ridge_fpr, ridge_tpr, label='Ridge Regression (AUC = %0.2f)' % ridge_auc)
plt.plot(rf_fpr, rf_tpr, label='Random Forest Classifier (AUC = %0.2f)' % rf_auc)

plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()

# Show the plot
plt.show()
```


    
![png](output_146_0.png)
    


### 3) Top five most important/relevant features

According to the random forest classifier, the top five most important features are, in order: lvdd, FractionalShortening, AgeAtHeartAttack, PericardialEffusion, and epss. A bar plot and a table represent these top five features.


```python
import seaborn as sns

importances_values = rf_final.feature_importances_
importances = pd.Series(importances_values, index=train_class.columns)
top5 = importances.sort_values(ascending=False)[:5]

plt.figure(figsize=(8, 6))
plt.title('Feature importances Top 5')
sns.barplot(x = top5, y = top5.index)
plt.show()
```


    
![png](output_148_0.png)
    



```python
# top 5 the most relevant features 
top5
```




    lvdd                    0.422951
    AgeAtHeartAttack        0.196247
    PericardialEffusion     0.133565
    FractionalShortening    0.122083
    epss                    0.098296
    dtype: float64


